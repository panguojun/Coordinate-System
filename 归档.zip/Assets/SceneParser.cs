using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SceneObject
{
    public string name;
    public string objectType; // 添加对象类型字段
    public List<float> position; // 修改为List<float>
    public List<float> rotation; // 修改为List<float>
    public List<float> scale; // 修改为List<float>
    public List<SceneObject> children;
}

public class SceneParser : MonoBehaviour
{
    public string jsonFilePath; // JSON文件路径
    
    private SceneObject rootObject;

    void Start()
    {
        // 读取JSON文件内容
        string jsonContent = System.IO.File.ReadAllText(jsonFilePath);

        // 解析JSON数据
        rootObject = JsonUtility.FromJson<SceneObject>(jsonContent);

        // 创建场景物体
        CreateSceneObject(rootObject, transform);
    }

    void CreateSceneObject(SceneObject sceneObject, Transform parentTransform)
    {
        // 创建游戏对象
        GameObject gameObject;
        if (sceneObject.objectType == "Cube") // 根据对象类型创建不同类型的基本体
        {
            gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
        }
        else if (sceneObject.objectType == "Sphere")
        {
            gameObject = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        }
        else
        {
            gameObject = new GameObject(sceneObject.name);
        }
        
        gameObject.transform.SetParent(parentTransform);
        gameObject.transform.localPosition = new Vector3(sceneObject.position[0], sceneObject.position[1], sceneObject.position[2]);
        gameObject.transform.localRotation = Quaternion.Euler(new Vector3(sceneObject.rotation[0], sceneObject.rotation[1], sceneObject.rotation[2]));
        gameObject.transform.localScale = new Vector3(sceneObject.scale[0], sceneObject.scale[1], sceneObject.scale[2]);

        // 创建子物体
        foreach (SceneObject childObject in sceneObject.children)
        {
            CreateSceneObject(childObject, gameObject.transform);
        }
    }
}