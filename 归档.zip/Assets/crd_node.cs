using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class crd_node : MonoBehaviour
{
    public Coord3 C;
    public Life L;

    void Start()
    {
        L = new Life(0, 3000, 10000);

        C = trans_coord(transform);
    }
    void Update()
    {
        long currentTime = (long)(Time.time * 1000); // 将秒转换为毫秒
        
        L.UpdateStatus(currentTime);

        if(L.status == "alive")
        {
            C.uCoord = C.uCoord * Quaternion.Euler(1f, 0f, 0f);

            transform.rotation = C.uCoord.ToQuaternion();
        }
    }

    public static UCoord3 trans_ucoord(Transform trans)
    {
        return new UCoord3(trans.localRotation);
    }
    public static Coord3 trans_coord(Transform trans)
    {
        return new Coord3(new UCoord3(trans.localRotation), trans.localScale, trans.localPosition);
    }
}
